let usersrc = 0;
let compsrc = 0;
let tr = 0;
const content = document.querySelectorAll(".content");
const msg = document.querySelector("#msg");
let trial = document.querySelector("#trial");
const trialSelect = document.querySelector("#trial1");
let restart = document.querySelector("#start");
let winner = document.querySelector("#winner");

content.forEach((content) => {
    content.addEventListener("click", () => {
        const userchoice = content.getAttribute("id");
        playgame(userchoice);
    });
});

const resartgame = () =>{
    msg.innerText = "Play your game";
    msg.style.backgroundColor = "rgb(2,2,36)";
    usersrc = 0;
    compsrc = 0;
    tr = 0;
    document.querySelector("#user-scr").innerText = `${usersrc}`;
    document.querySelector("#comp-scr").innerText = `${compsrc}`;
    document.querySelector("#trial").innerText = `${tr}`;
    content.forEach((content) => {
        content.style.pointerEvents = "all";
    });
    over.classList.add("hide");
    winner.innerText = "Winner";
}

const playgame = (userchoice) => {
    const compchoice = generateComputerChoice();
    if (userchoice === compchoice) {
        drawgame(userchoice);
    } else {
        let userwin = true;
        if (userchoice === "rock") {
            userwin = compchoice !== "paper";
        } else if (userchoice === "paper") {
            userwin = compchoice !== "scissors";
        } else {
            userwin = compchoice !== "rock";
        }
        showwinner(userwin, userchoice, compchoice);
    }

    if (tr >= parseInt(trialSelect.value)) {
        content.forEach((content) => {
            content.style.pointerEvents = "none";
        });
        let over = document.querySelector("#over");
        over.classList.remove("hide");

    }
    whoiswinner();
};

const whoiswinner =() =>{
    if(compsrc > usersrc){
        winner.innerText = "Computer is Winner";
    }
    else if(compsrc < usersrc){
        winner.innerText = "You are the Winner";
    }
    else{
        winner.innerText = "Ohh.! It's a tie"
    }
}

const showwinner = (userwin, userchoice, compchoice) => {
    if (userwin) {
        msg.innerText = `Bravo!!! You win ${userchoice} beats ${compchoice}`;
        usersrc++;
        document.querySelector("#user-scr").innerText = `${usersrc}`;
        msg.style.backgroundColor = "green";
        confetti({
            particleCount: 500,
            spread: 80,
            origin: { y: 1 }
        });
    } else {
        msg.innerText = `Hashhh !!! Computer wins ${compchoice} beats ${userchoice}`;
        compsrc++;
        document.querySelector("#comp-scr").innerText = `${compsrc}`;
        msg.style.backgroundColor = "red";
    }
};

const drawgame = (userchoice) => {
    msg.innerText = `It was a Draw you both chose ${userchoice}`;
    msg.style.backgroundColor = "rgb(2, 2, 36)";
};

const generateComputerChoice = () => {
    const options = ["rock", "paper", "scissors"];
    const randidx = Math.floor(Math.random() * 3);
    tr++;
    trial.innerText = `Trial: ${tr}`;
    return options[randidx];
};

restart.addEventListener("click", resartgame);